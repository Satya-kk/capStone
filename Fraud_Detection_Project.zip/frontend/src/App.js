import React, { useState } from "react";
import axios from "axios";

function App() {
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    const features = new Array(30).fill(0);

    try {
      const response = await axios.post(
        "http://127.0.0.1:5000/predict",
        { features }
      );
      setResult(response.data);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Credit Card Fraud Detection</h1>
      <button onClick={handleSubmit}>Check Transaction</button>

      {result && (
        <div style={{ marginTop: "20px" }}>
          <h3>
            Prediction: {result.prediction === 1 ? "Fraud" : "Not Fraud"}
          </h3>
          <p>Probability: {result.probability.toFixed(4)}</p>
        </div>
      )}
    </div>
  );
}

export default App;
